/**
 *
 */
package com.cnk.travelogix.air.auth.addon.service.impl;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.oauth2.model.Userinfo;


/**
 * @author I319924
 *
 */
public class GoogleAuthTemplateImpl extends GoogleAuthTemplate
{

	/*
	 * (non-Javadoc)
	 *
	 * @see com.cnk.travelogix.air.auth.addon.service.impl.GoogleAuthTemplate#getUserInfo(java.lang.String)
	 */
	private static final String GOOGLE_AUTH_URL = "https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=";

	private final Logger LOG = Logger.getLogger(GoogleAuthTemplateImpl.class);

	@Override
	public Userinfo getUserInfo(final String token)
	{
		final JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
		final HttpClient httpClient = new DefaultHttpClient();
		try
		{
			final HttpGet httpGetRequest = new HttpGet(GOOGLE_AUTH_URL + token);
			final HttpResponse httpResponse = httpClient.execute(httpGetRequest);
			final HttpEntity entity = httpResponse.getEntity();
			if (entity != null)
			{
				final InputStream inputStream = entity.getContent();
				return jsonFactory.fromInputStream(inputStream, Userinfo.class);
			}
			else
			{
				LOG.info("invalid google Auth Token");
			}
		}
		catch (final IOException e)
		{
			LOG.info(e.getMessage());
		}
		finally
		{
			httpClient.getConnectionManager().shutdown();
		}
		return null;
	}
}
