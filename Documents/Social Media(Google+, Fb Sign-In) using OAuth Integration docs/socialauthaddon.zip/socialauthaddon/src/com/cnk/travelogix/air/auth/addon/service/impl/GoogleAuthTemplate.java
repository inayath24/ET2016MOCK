/**
 *
 */
package com.cnk.travelogix.air.auth.addon.service.impl;

import com.google.api.services.oauth2.model.Userinfo;


/**
 * @author I319924
 *
 */
public abstract class GoogleAuthTemplate
{
	public abstract Userinfo getUserInfo(String paramString);
}
