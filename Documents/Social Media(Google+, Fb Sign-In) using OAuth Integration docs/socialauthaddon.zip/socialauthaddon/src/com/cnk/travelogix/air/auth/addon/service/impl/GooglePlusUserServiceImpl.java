/**
 *
 */
package com.cnk.travelogix.air.auth.addon.service.impl;

import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.user.impl.DefaultUserService;

import org.apache.log4j.Logger;

import com.cnk.travelogix.air.auth.addon.enums.SocialType;
import com.cnk.travelogix.air.auth.addon.service.GooglePlusUserService;
import com.google.api.services.oauth2.model.Userinfo;


/**
 * @author I319924
 *
 */
public class GooglePlusUserServiceImpl extends DefaultUserService implements GooglePlusUserService
{

	private final Logger LOG = Logger.getLogger(GooglePlusUserService.class);

	private GoogleAuthTemplate googleAuthTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cnk.travelogix.air.auth.addon.service.GooglePlusUserService#createCustomer(java.lang.String)
	 */
	@Override
	public CustomerModel createCustomer(final Userinfo info)
	{
		final CustomerModel customerModel = getModelService().create(CustomerModel.class);
		customerModel.setUid(info.getEmail());
		customerModel.setName(info.getName());
		customerModel.setSocialId(info.getId());
		customerModel.setSocialId(SocialType.GOOGLEPLUS.getCode());
		getModelService().save(customerModel);
		return customerModel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cnk.travelogix.air.auth.addon.service.GooglePlusUserService#isGoogleCustomer(java.lang.String)
	 */
	@Override
	public boolean isGoogleCustomer(final Userinfo info)
	{
		final UserModel user = getUserForUID(info.getEmail());
		if (user instanceof CustomerModel)
		{
			if (SocialType.GOOGLEPLUS.getCode().equals(((CustomerModel) user).getSocialType()))
			{
				return true;
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cnk.travelogix.air.auth.addon.service.GooglePlusUserService#getGoogleUserinfo(java.lang.String)
	 */
	@Override
	public Userinfo getGoogleUserinfo(final String token)
	{
		return googleAuthTemplate.getUserInfo(token);
	}

	/**
	 * @return the googleAuthTemplate
	 */
	public GoogleAuthTemplate getGoogleAuthTemplate()
	{
		return googleAuthTemplate;
	}

	/**
	 * @param googleAuthTemplate
	 *           the googleAuthTemplate to set
	 */
	public void setGoogleAuthTemplate(final GoogleAuthTemplate googleAuthTemplate)
	{
		this.googleAuthTemplate = googleAuthTemplate;
	}

}
