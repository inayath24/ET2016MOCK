    	function onSignIn(googleUser) {
    		var id_token = googleUser.getAuthResponse().id_token;
    		gapi.auth2.getAuthInstance().signOut().then(function() {
    		window.location.replace("https://electronics.local:9002/electronics/en/oauth2callback/?token="+id_token);
    		});
    	};
    	
    	
    	(function() {
    		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    		ga.src = ('https:' == document.location.protocol ? 'https://apis' : 'http://www') + '.google.com/js/platform.js';
    		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    	})();
