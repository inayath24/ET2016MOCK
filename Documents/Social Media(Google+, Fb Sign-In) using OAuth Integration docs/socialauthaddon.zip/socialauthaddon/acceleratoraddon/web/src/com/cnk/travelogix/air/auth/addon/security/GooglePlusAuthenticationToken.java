/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
package com.cnk.travelogix.air.auth.addon.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;


public class GooglePlusAuthenticationToken extends AbstractAuthenticationToken
{
	private static final long serialVersionUID = 320L;
	private Object principal;

	/**
	 * @param principal
	 *           the principal to set
	 */
	public void setPrincipal(final Object principal)
	{
		this.principal = principal;
	}

	private Object credentials;

	public GooglePlusAuthenticationToken(final Object principal, final Object credentials)
	{
		super(null);
		this.principal = principal;
		this.credentials = credentials;
		setAuthenticated(false);
	}

	public GooglePlusAuthenticationToken(final Object principal, final Object credentials,
			final Collection<? extends GrantedAuthority> authorities)
	{
		super(authorities);
		this.principal = principal;
		this.credentials = credentials;
		super.setAuthenticated(true);
	}

	public Object getCredentials()
	{
		return this.credentials;
	}

	public Object getPrincipal()
	{
		return this.principal;
	}

	@Override
	public void setAuthenticated(final boolean isAuthenticated) throws IllegalArgumentException
	{
		if (isAuthenticated)
		{
			throw new IllegalArgumentException(
					"Once created you cannot set this token to authenticated. Create a new instance using the constructor which takes a GrantedAuthority list will mark this as authenticated.");
		}

		super.setAuthenticated(false);
	}

	@Override
	public void eraseCredentials()
	{
		super.eraseCredentials();
		this.credentials = null;
	}
}