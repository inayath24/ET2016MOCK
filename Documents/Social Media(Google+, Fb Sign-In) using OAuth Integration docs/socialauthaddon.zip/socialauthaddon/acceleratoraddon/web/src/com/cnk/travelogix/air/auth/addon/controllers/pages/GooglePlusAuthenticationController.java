/**
 *
 */
package com.cnk.travelogix.air.auth.addon.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.security.AutoLoginStrategy;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cnk.travelogix.air.auth.addon.service.GooglePlusUserService;


/**
 * @author I319924
 *
 */
@Controller
@RequestMapping(value = "/oauth2callback")
public class GooglePlusAuthenticationController
{
	private final Logger LOG = Logger.getLogger(GooglePlusAuthenticationController.class);

	public static final String REDIRECT_PREFIX = "redirect:";

	@Autowired
	AutoLoginStrategy googlePlusAutoLoginStrategy;

	@Resource
	HttpSessionRequestCache accHttpSessionRequestCache;

	@Resource
	private GooglePlusUserService googlePlusUserService;

	@RequestMapping(method = RequestMethod.GET)
	public String getRequest(final HttpServletRequest request, final HttpServletResponse response)
	{
		final String token = request.getParameter("token");
		if (token == null)
		{
			LOG.info("Invalid Token !!!");
			return "redirect:/login";
		}
		googlePlusAutoLoginStrategy.login("GooglePlus", token, request, response);

		return REDIRECT_PREFIX + getSuccessRedirect(request, response);
	}

	protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (accHttpSessionRequestCache.getRequest(request, response) != null)
		{
			return accHttpSessionRequestCache.getRequest(request, response).getRedirectUrl();
		}
		return "/";
	}
}
