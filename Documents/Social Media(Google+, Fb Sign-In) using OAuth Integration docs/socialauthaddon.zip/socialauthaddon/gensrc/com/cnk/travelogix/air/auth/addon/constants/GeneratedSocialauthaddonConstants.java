/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 3 Mar, 2016 1:35:24 PM                      ---
 * ----------------------------------------------------------------
 */
package com.cnk.travelogix.air.auth.addon.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedSocialauthaddonConstants
{
	public static final String EXTENSIONNAME = "socialauthaddon";
	public static class TC
	{
		public static final String SOCIALTYPE = "SocialType".intern();
	}
	public static class Attributes
	{
		public static class Customer
		{
			public static final String SOCIALID = "socialId".intern();
			public static final String SOCIALTYPE = "socialType".intern();
		}
	}
	public static class Enumerations
	{
		public static class SocialType
		{
			public static final String GOOGLEPLUS = "GooglePlus".intern();
			public static final String LINKEDIN = "LinkedIn".intern();
			public static final String FACEBOOK = "Facebook".intern();
			public static final String POCKET = "Pocket".intern();
			public static final String CNK = "CNK".intern();
		}
	}
	
	protected GeneratedSocialauthaddonConstants()
	{
		// private constructor
	}
	
	
}
